#include <stdio.h>
#include <string.h>

struct Student {
    char name[50];
    int id;
    float marks[5];
    float total;
    float percent;
    char grade;
};

void calculate_grade(struct Student *s) {
    if(s->percent >= 90) s->grade = 'A';
    else if(s->percent >= 75) s->grade = 'B';
    else if(s->percent >= 60) s->grade = 'C';
    else if(s->percent >= 45) s->grade = 'D';
    else s->grade = 'F';
}

void enter_data(struct Student s[], int *n) {
    int i, j;
    printf("\nEnter number of students: ");
    scanf("%d", n);

    for(i = 0; i < *n; i++) {
        s[i].total = 0;

        printf("\nEnter details of student %d\n", i + 1);
        printf("Name: ");
        scanf(" %[^\n]s", s[i].name);

        printf("ID: ");
        scanf("%d", &s[i].id);

        printf("Enter marks of 5 subjects:\n");
        for(j = 0; j < 5; j++) {
            printf("Subject %d: ", j + 1);
            scanf("%f", &s[i].marks[j]);
            s[i].total += s[i].marks[j];
        }

        s[i].percent = (s[i].total / 500.0) * 100;
        calculate_grade(&s[i]);
    }
}

void display(struct Student s[], int n) {
    int i;
    printf("\n-------------------- RESULT SHEET --------------------\n");
    for(i = 0; i < n; i++) {
        printf("\nName: %s\n", s[i].name);
        printf("ID: %d\n", s[i].id);
        printf("Total Marks: %.2f / 500\n", s[i].total);
        printf("Percentage: %.2f%%\n", s[i].percent);
        printf("Grade: %c\n", s[i].grade);
    }
}

void save_to_file(struct Student s[], int n) {
    FILE *fp = fopen("grading_result.txt", "w");
    int i;
    if(fp == NULL) {
        printf("File error!\n");
        return;
    }

    for(i = 0; i < n; i++) {
        fprintf(fp, "%s %d %.2f %.2f %c\n", s[i].name, s[i].id, s[i].total, s[i].percent, s[i].grade);
    }
    fclose(fp);
    printf("\nResults saved to grading_result.txt successfully!\n");
}

void search_by_id(struct Student s[], int n) {
    int id, i, found = 0;
    printf("Enter student ID to search: ");
    scanf("%d", &id);

    for(i = 0; i < n; i++) {
        if(s[i].id == id) {
            printf("\nStudent Found!\n");
            printf("Name: %s\nID: %d\nPercentage: %.2f%%\nGrade: %c\n", s[i].name, s[i].id, s[i].percent, s[i].grade);
            found = 1;
            break;
        }
    }
    if(!found) printf("Student not found!\n");
}

void sort_by_percentage(struct Student s[], int n) {
    int i, j;
    struct Student temp;
    for(i = 0; i < n - 1; i++) {
        for(j = i + 1; j < n; j++) {
            if(s[j].percent > s[i].percent) {
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }
        }
    }
    printf("\nSorting complete! (Highest percentage first)\n");
}

int main() {
    struct Student s[100];
    int n = 0, choice;

    while(1) {
        printf("\n================ STUDENT GRADING SYSTEM ================\n");
        printf("1. Enter student data\n");
        printf("2. Display results\n");
        printf("3. Save results to file\n");
        printf("4. Search by ID\n");
        printf("5. Sort by percentage\n");
        printf("6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1: enter_data(s, &n); break;
            case 2: display(s, n); break;
            case 3: save_to_file(s, n); break;
            case 4: search_by_id(s, n); break;
            case 5: sort_by_percentage(s, n); break;
            case 6: return 0;
            default: printf("Invalid choice!\n");
        }
    }
}